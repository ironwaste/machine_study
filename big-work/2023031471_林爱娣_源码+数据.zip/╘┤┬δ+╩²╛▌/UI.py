import sys
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.ensemble import RandomForestRegressor
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QMessageBox, QVBoxLayout, \
    QHBoxLayout, QComboBox

# 假设这是存储用户数据的字典
users = {}


class RegisterWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('注册界面')
        self.setFixedSize(500, 400)  # 只需要设置一次固定大小
        self.setGeometry(620, 350, 250, 200)

        # 设置窗口的样式表，背景为纯白色，边框为圆角
        self.setStyleSheet("QWidget {border-radius: 10px; }"
                           "QLineEdit { border: 1px solid #cccccc; padding: 2px; }"  # 为输入框添加样式
                           "QPushButton { background-color: #4CAF50; color: white; border-radius: 5px; }"
                           "QPushButton:hover { background-color: #45a049; }")  # 为按钮添加悬停样式
        layout = QVBoxLayout()
        # 创建用户名的标签和输入框，并使用水平布局管理器
        username_layout = QHBoxLayout()
        self.label_username = QLabel('用户名:')
        username_layout.addWidget(self.label_username)
        self.entry_username = QLineEdit()
        username_layout.addWidget(self.entry_username)

        # 创建密码的标签和输入框，并使用水平布局管理器
        password_layout = QHBoxLayout()
        self.label_password = QLabel('密码:')
        password_layout.addWidget(self.label_password)
        self.entry_password = QLineEdit()
        self.entry_password.setEchoMode(QLineEdit.Password)
        password_layout.addWidget(self.entry_password)

        # 将水平布局添加到垂直布局中
        layout.addLayout(username_layout)
        layout.addLayout(password_layout)

        # 注册按钮
        self.register_button = QPushButton('注册')
        self.register_button.clicked.connect(self.register)
        self.register_button.setFixedSize(473, 40)
        layout.addWidget(self.register_button)

        self.setLayout(layout)

    def register(self):
        username = self.entry_username.text()
        password = self.entry_password.text()
        # 设置窗口的样式表，背景为纯白色，边框为圆角
        self.setStyleSheet("QWidget {border-radius: 10px; }"
                           "QLineEdit { border: 1px solid #cccccc; padding: 2px; }"  # 为输入框添加样式
                           "QPushButton { background-color: #4CAF50; color: white; border-radius: 5px; }"
                           "QPushButton:hover { background-color: #45a049; }")  # 为按钮添加悬停样式

        if username in users:
            QMessageBox.warning(self, '警告', '用户名已存在！')
        else:
            users[username] = password
            self.close()
            QMessageBox.information(self, '成功', '用户注册成功！')
            # 注册成功后，可以打开登录窗口
            LoginWindow()


class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('登录界面')
        self.setFixedSize(500, 400)  # 只需要设置一次固定大小
        self.setGeometry(620, 350, 250, 200)

        # 设置窗口的样式表，背景为纯白色，边框为圆角
        self.setStyleSheet("QWidget {border-radius: 10px; }"
                           "QLineEdit { border: 1px solid #cccccc; padding: 2px; }"  # 为输入框添加样式
                           "QPushButton { background-color: #4CAF50; color: white; border-radius: 5px; }"
                           "QPushButton:hover { background-color: #45a049; }")  # 为按钮添加悬停样式

        layout = QVBoxLayout()

        # 创建用户名的标签和输入框，并使用水平布局管理器
        username_layout = QHBoxLayout()
        self.label_username = QLabel('用户名:')
        username_layout.addWidget(self.label_username)
        self.entry_username = QLineEdit()
        username_layout.addWidget(self.entry_username)

        # 创建密码的标签和输入框，并使用水平布局管理器
        password_layout = QHBoxLayout()
        self.label_password = QLabel('密码:')
        password_layout.addWidget(self.label_password)
        self.entry_password = QLineEdit()
        self.entry_password.setEchoMode(QLineEdit.Password)
        password_layout.addWidget(self.entry_password)

        # 将水平布局添加到垂直布局中
        layout.addLayout(username_layout)
        layout.addLayout(password_layout)

        # 登录按钮
        self.login_button = QPushButton('登录')
        self.login_button.clicked.connect(self.login)
        self.login_button.setFixedSize(473, 40)
        layout.addWidget(self.login_button)

        self.setLayout(layout)

    def login(self):
        username = self.entry_username.text()
        password = self.entry_password.text()
        # 设置窗口的样式表，背景为纯白色，边框为圆角
        self.setStyleSheet("QWidget {border-radius: 10px; }"
                           "QLineEdit { border: 1px solid #cccccc; padding: 2px; }"  # 为输入框添加样式
                           "QPushButton { background-color: #4CAF50; color: white; border-radius: 5px; }"
                           "QPushButton:hover { background-color: #45a049; }")  # 为按钮添加悬停样式

        if username in users and users[username] == password:
            QMessageBox.information(self, '成功', '用户登录成功！')
            self.close()
            self.forecast_window = ForecastWindow()
            self.forecast_window.show()
        else:
            QMessageBox.warning(self, '错误', '用户名或密码错误！')


class ForecastWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('二手车价格预测')
        self.setGeometry(400, 200, 250, 200)
        self.setFixedSize(1000, 650)

        layout = QVBoxLayout()
        # brand_layout
        brand_layout = QHBoxLayout()
        self.label_brand = QLabel('品牌:')
        self.brand_LE = QComboBox()
        self.brand_LE.addItems(['MINI', 'Lincoln', 'Chevrolet', 'Genesis', 'Mercedes-Benz', 'Audi', 'Ford', 'BMW',
                                'Cadillac', 'Land', 'GMC', 'Toyota', 'Hyundai', 'Volvo', 'Volkswagen', 'Buick', 'RAM',
                                'Hummer', 'Alfa', 'INFINITI', 'Jeep', 'Porsche', 'McLaren', 'Honda', 'Lexus', 'Dodge',
                                'Nissan', 'Jaguar', 'Acura', 'Kia', 'Mitsubishi', 'Rolls-Royce', 'Maserati', 'Pontiac',
                                'Saturn', 'Bentley', 'Mazda', 'Subaru', 'Ferrari', 'Aston', 'Lamborghini', 'Chrysler',
                                'Lucid', 'Lotus', 'Scion', 'smart', 'Tesla', 'Karma', 'Plymouth', 'Suzuki', 'FIAT',
                                'Rivian', 'Saab', 'Bugatti', 'Mercury', 'Polestar', 'Maybach'])
        self.brand_LE.setFixedSize(850, 30)
        brand_layout.addWidget(self.label_brand)
        brand_layout.addWidget(self.brand_LE)
        # 将品牌选择区域的布局添加到主布局
        layout.addLayout(brand_layout)
        # model_layout
        model_layout = QHBoxLayout()
        self.label_model = QLabel('具体型号:')
        self.model_LE = QComboBox()
        self.model_LE.addItems(['Cooper S Base', 'LS V8', 'Silverado 2500 LT', 'G90 5.0 Ultimate', 'Metris Base', 'A6 2.0T Sport',
             'A8 L 3.0T', 'Silverado 1500 1LZ', 'F-150 XLT', 'M4 Base', 'Camaro 1LT', 'Escalade ESV Platinum',
             'S4 3.0T Premium Plus', 'Rover Range Rover P530 SE SWB', 'AMG C 63 S', 'Yukon Denali', 'Rover Defender SE',
             'Tundra SR5', 'AMG C 63 Base', 'Rover Defender S', 'Equus Signature', 'Mustang Premium', 'A8 L 55',
             'XC70 T6 Platinum', 'Sequoia Limited', 'F-250 XLT', 'Tacoma PreRunner', 'A5 2.0T Premium',
             'A3 2.0T Premium', 'E-Class E 300', 'E-Class E 350 4MATIC', 'Jetta S', '528 i xDrive', '330 i xDrive',
             'AMG G 63 Base', 'C-Class C 300 4MATIC Sport', 'Enclave Premium', '328 xi', 'Corvette Grand Sport',
             'AMG GT 53 Base', '1500 Laramie', 'Corvette Base', 'H2 Base', 'Romeo Stelvio Ti Sport', 'QX60 Base',
             'Genesis Coupe 3.8 Base', 'M6 Base', 'Gladiator Rubicon', 'Thunderbird Deluxe',
             'Rover Range Rover Sport HSE', 'SL-Class SL500 Roadster', 'GLS 450 Base 4MATIC', 'Cayenne Base',
             'Corvette Stingray w/2LT', 'SSR Base', 'M5 Base', '86 860 Special Edition', 'G-Class G 550 4MATIC',
             'Camry SE', 'E-Class E 350', '570S Spider', 'Highlander XLE', 'Sequoia Platinum', 'F-250 King Ranch',
             'CR-V EX-L', '911 Carrera 4S', 'Camry Solara SLE', '4Runner SR5', 'M3 Base', 'RS 7 4.0T Prestige',
             'Camry LE', 'Q5 2.0T Premium Plus', 'Expedition Limited', 'Mustang EcoBoost Premium', 'Wrangler X',
             'Focus RS Base', 'Countryman Cooper S ALL4', 'NX 300 Base', 'Mustang GT', 'Highlander Limited Platinum',
             '430 i', 'Ram 1500 Laramie Mega Cab', 'Xterra S', 'Tahoe LT', 'S-Class S 63 AMG', 'Suburban 1500 LTZ',
             'AMG GT AMG GT S', 'E-Class E 550', 'XJ8 L', 'AMG CLA 45 Base 4MATIC', 'TT 1.8T', 'Escalade Platinum',
             'M8 Gran Coupe Competition', 'ILX Premium Package', 'Suburban LT', 'Excursion Limited', 'MKZ Base',
             'Sportage LX', 'X5 PHEV xDrive45e', 'CLA-Class CLA 250', 'SL-Class SL 550', 'F-350 Platinum',
             'Liberty Sport', 'CTS Performance', 'Grand Cherokee L Limited', 'QX70 Base', 'F-150 Lariat', 'Durango GT',
             'S80 3.2', 'CTS Base', 'Highlander Limited', 'Transit Connect XLT', 'Sierra 2500 Base',
             'Dakota Big Horn/Lone Star', 'Outlander Sport ES', 'F-250 Lariat', 'A-Class A 220 4MATIC', 'Ghost Base',
             'Camry Solara SLE V6', '911 Turbo S', 'Ranger XLT', 'X3 xDrive30i', 'Ghibli S Q4', '911 Carrera',
             'Acadia SLT-1', 'Avalanche 1500 LTZ', 'Q60 3.0t Red Sport 400', 'Pathfinder SL', 'Solstice GXP',
             'Yukon XL SLT', 'M240 i', 'Sky Red Line', '540 i xDrive', 'Q7 3.0T Premium Plus', 'Sierra 1500 SLT',
             'Romeo Giulia Base', 'GT-R Premium', 'Expedition Max King Ranch', 'Cayenne GTS Coupe AWD', 'QX60 Luxe',
             'Silverado 1500 RST', 'A4 2.0T Premium', 'GX 460 Base', 'Navigator Reserve',
             'Rover Range Rover Sport HSE Dynamic', 'Continental GTC Base', 'Highlander SE', 'Mustang GT Premium',
             'CLK-Class CLK 350', 'Wrangler Unlimited', 'S-10 LS Crew Cab', 'Mustang V6', 'LC 500 Base',
             'Expedition EL King Ranch', 'Suburban Premier', 'G37 S Sport', 'Cayenne Turbo S', 'Boxster Base',
             'Sorento SX', 'Wrangler Unlimited Sahara', 'Continental GT Base', 'X1 xDrive 28i', 'Explorer XLT',
             '4Runner SR5 Premium', 'CTS Luxury', 'Silverado 1500 1LT', 'XJ6 Vanden Plas', 'Corvette Stingray w/3LT',
             'Mazda6 i Touring', 'Macan GTS', 'Q50 3.0t Red Sport 400', 'Wrangler Unlimited Rubicon',
             'Genesis Coupe 3.8 Track', 'Silverado 2500 LT H/D Extended Cab', 'Rover Range Rover Sport Supercharged',
             'Telluride SX', 'AMG C AMG C 63 S', 'Wrangler Unlimited Sport', 'NV Passenger NV3500 HD SL V8',
             'Explorer Platinum', 'C-Class C 300 4MATIC', '335 i xDrive', 'WRX Base',
             'Rover Range Rover 3.0L V6 Supercharged HSE', 'Cayenne Turbo', 'Tundra Limited', 'F-150 Raptor',
             'RC 350 Base', 'Camaro 2SS', 'S3 2.0T Tech Premium Plus', 'AMG C 43 Base 4MATIC', 'Escalade EXT Base',
             '911 GT2 RS', 'GranTurismo Sport', 'RX 350 F Sport', 'Rover Range Rover P530 SE LWB 7 Seat',
             'Rover Range Rover Sport Supercharged HSE', 'S-Class S 580 4MATIC', 'Suburban High Country', 'Element EX',
             'Wrangler Sport', 'A6 3.0T Premium Plus', 'Martin Vantage GT Base', 'ES 300h Base', 'TL Type S',
             'Grand Cherokee L Laredo', 'CTS-V Base', 'Ram 1500 ST', '328 i xDrive', 'Edge Titanium', 'Panamera 4S',
             'Impreza WRX Sti', 'Grand Cherokee Limited', 'Camry Hybrid Base', 'Outback Limited XT', 'GX 470 Base',
             'ES 350 Base', 'GV70 3.5T Sport', 'Gallardo LP550-2', 'Forester 2.5i Limited', 'S-Class S 550 4MATIC',
             'WRX Limited', 'RC F Base', '128 i', 'Transit Connect XL', 'Q50 Hybrid Sport', 'Grand Caravan SE',
             'CLS-Class CLS 550', 'Avalon XLE', 'Transit-350 Base', 'M8 Base', 'Rover Range Rover Velar P380 S',
             'AMG E 63 S 4MATIC', 'Town & Country Touring-L', 'A6 3.0T Prestige', 'LS 460 L', 'Equinox LT',
             'GX 460 Premium', 'SRX Luxury Collection', 'Rover LR4 HSE', 'IS 250 Base', 'Rover Range Rover Evoque Pure',
             'AMG GLS 63 4MATIC', 'Rover Range Rover Evoque HSE Dynamic', 'F-TYPE R', 'Forte GT-Line',
             '350Z Enthusiast', 'Mazda6 Touring', '300C Base', 'M3 CS', 'Civic EX', '911 Turbo',
             'Challenger SRT Hellcat', 'H3 Base', 'Eurovan MV', 'Rover Defender 110 SE', 'GLS 550 Base 4MATIC',
             '750 i xDrive', '2500 Longhorn', 'A7 3.0T Prestige', 'Accord EX-L 2.0T', 'XT5 Base',
             'Bronco Sport Big Bend', 'Rover Range Rover Velar R-Dynamic SE', 'Ram 1500 SRT-10 Quad Cab',
             'RX 350 F Sport Performance', 'Rover Range Rover 5.0L Supercharged Autobiography LWB',
             'E350 Super Duty XLT', 'Wrangler Sahara Altitude', 'Sprinter High Roof', 'MX-5 Miata Base',
             'Wagoneer Series III', 'M4 Competition xDrive', 'Avalanche 1500 LS', 'Q60 3.0T Premium', 'Altima 2.5 SL',
             'QX80 Luxe', 'Explorer Eddie Bauer', '740 i', 'Sonata Hybrid Limited', '328 i', 'Gladiator Overland',
             'Sonata GLS', 'Frontier SV', 'Sorento SX Prestige', 'Bronco Outer Banks Advanced', '1500 Limited',
             'F-350 Lariat', 'MKC Base', 'A6 55 Premium', '650 Gran Coupe i xDrive', 'Bronco Wildtrak Advanced',
             'XF 25t Prestige', 'F12berlinetta Base', 'F-150 Platinum', 'IS 250C Base', 'Camaro Z28', 'CX-30 Select',
             'Tundra SR5 Access Cab', 'Land Cruiser Base', 'AMG GLE 43 Coupe 4MATIC', '335 is', 'Compass Sport',
             'Impreza WRX', 'XF Premium', 'RS 7 4.0T Performance Prestige', 'Tundra SR5 Double Cab',
             'F-PACE 30t R-Sport', 'F-250 XL SuperCab H/D', 'Rover LR2 Base', 'Silverado 1500 2LT', 'Cayman R',
             'AMG G 63 4MATIC', 'Suburban 1500 LS', 'Sprinter 2500', 'Edge SEL', 'Escalade ESV Sport', 'ILX 2.4L',
             'F-250 Platinum', '911 GT3', '1500 Tradesman/Express', 'Envision Essence', 'Explorer ST',
             'Sprinter 2500 Standard Roof', 'Macan S', 'Wrangler Sahara', 'Bronco Big Bend Advanced',
             'Impreza 2.0i Premium', 'Cayenne GTS', '911 Carrera S', 'Transit-350 XLT', 'Nautilus Reserve',
             'Maxima 3.5 SR', 'X1 xDrive28i', 'Rover Discovery Sport SE', 'Sprinter 2500 High Roof', 'LX 570 Three-Row',
             'Shelby GT350R Base', 'Rover Range Rover HSE SWB', 'GLK-Class GLK 350', 'Shelby GT500 Base',
             'Fusion Hybrid SE', 'Acadia SLE', 'Murano SL', 'X5 xDrive40i', '340 i', 'AMG GT 63 S 4-Door',
             'Impreza WRX STI', 'Golf GTI 2.0T SE 4-Door', 'Camaro 1SS', '535 i xDrive', 'Yukon XL Denali',
             'GL-Class GL 450 4MATIC', 'Optima LX', 'Tacoma Double Cab', 'F-250 XLT SuperCab Super Duty',
             'Continental GT V8 S', 'RX-8 Grand Touring', 'Wrangler Unlimited Freedom Edition', 'S-Class S 560 4MATIC',
             '1500 Big Horn', 'Camaro Base', 'Trailblazer LS', 'RS 5 2.9T', 'Rover Range Rover P525 Westminster',
             '911 Carrera C2S', 'Expedition Timberline', 'XK8 Base', 'Gladiator Sport S', 'S5 3.0T Premium Plus',
             'K900 5.0L', 'Golf Auto TSI S', 'Rover Defender V8', 'Urus Base', 'RX 450h Base', 'Outback 2.5i Limited',
             '428 i xDrive SULEV', '911 GT3 RS', 'IS 300 Base', 'Telluride S',
             'Rover Range Rover Velar P250 S R-Dynamic', 'XT6 Sport AWD', 'Durango SRT 392', 'Sportage Nightfall',
             'Crossfire Limited', '2500 Big Horn', 'ProMaster 2500 Window Van High Roof', 'GranTurismo Base',
             '720S Performance', 'Silverado 1500 LT Crew Cab', 'SLK-Class SLK 350', '330 i', 'A3 2.0T Tech Premium',
             'M235 i', 'CX-5 Touring', '911 Carrera 4S Cabriolet', '1500 Rebel',
             'Rover Range Rover 3.0L Supercharged HSE', 'Fusion SE', 'CTS 3.6L Premium', 'Cullinan',
             'Ram 2500 Laramie Quad Cab', 'A7 3.0T Premium Plus', 'Escape XLT', 'RX 300 Base', 'A6 55 Prestige',
             'Pilot EX-L', 'Quattroporte S Q4 GranLusso', 'Rover Range Rover Supercharged LWB', 'Focus ST Base',
             '528 i', 'Expedition EL Limited', 'Camaro 2LT', 'E-Class E 400 4MATIC', 'Firebird Base', 'Expedition XLT',
             'Suburban LTZ', 'S2000 Base', 'Clubman Cooper S ALL4', 'Continental GT V8', 'Charger Scat Pack',
             'CX-30 Premium Package', 'M340 i xDrive', 'Sierra 1500 SLE Crew Cab', 'Cayman S', 'A8 4.0T',
             'Sierra 1500 Denali', 'Mustang SVT Cobra', '1500 Longhorn', 'Focus SE', 'Matrix XR',
             'A4 2.0T Premium quattro', 'LS 460 Crafted Line', 'C70 T5', 'Rover Discovery HSE LUXURY', 'Genesis 3.8',
             'Cayman Base', 'BRZ Limited', 'Suburban 2500', 'Q7 55 Prestige', 'C-Class C 300', 'Dakota SLT Quad Cab',
             'Suburban Z71', 'Civic LX', 'Explorer Limited', 'Accord EX-L', 'Firebird Trans Am', 'Sierra 2500 Denali',
             'GLC 300 Base 4MATIC', 'Navigator L Select', 'IS 350 Base', '435 i', 'MKZ Reserve I',
             'Corvette Stingray Z51', 'Mazda3 i Touring', 'Transit Connect XL w/Rear Symmetrical Doors', 'Santa Fe SEL',
             'Wrangler Unlimited Sport S', 'Durango R/T', 'XF 25t Premium', 'Cayenne Diesel', 'Ghibli S Q4 GranSport',
             'Town Car Signature', 'Ram 3500 Quad Cab DRW', 'Escalade Premium', '911 Carrera Cabriolet', 'RS 7 4.0T',
             'Golf R 4-Door', 'Sorento SXL', 'CX-9 Carbon Edition', 'CX-9 Signature', 'TL 3.2',
             'Silverado 1500 LT Trail Boss', 'Q8 3.0T Prestige', 'R8 5.2', 'Enclave Essence', 'MKZ Reserve',
             'A7 Premium', 'Rover Range Rover Velar R-Dynamic S', 'S-Class S500', 'SQ5 3.0T Prestige',
             'Rover Discovery S', 'Excursion XLS', 'Yukon SLT', 'MKC Reserve', 'GL-Class GL 550', 'Hardtop Cooper S',
             'Charger R/T Scat Pack', 'MKS EcoBoost', 'M440 i xDrive', 'Camaro LT1', 'Boxster S', 'RX 350 Base',
             'Forester 2.5 XT', 'M8 Competition', 'Forester Base', 'Tucson Limited', 'Q7 3.0T Prestige',
             'RS 7 4.0T quattro', 'Mazda6 Grand Touring', 'Monte Carlo SS', '718 Cayman GT4', 'M760 i xDrive',
             'Mazda6 Signature', 'M2 Base', 'S6 4.0T Prestige', '1500 Classic SLT', 'SQ5 3.0T Premium Plus',
             'XC90 T6 Momentum', 'S8 4.0T quattro', 'Rover Range Rover Sport P400 SE Dynamic', 'C-HR LE', 'TT 2.0T',
             'Town Car Base', 'Commander Sport', 'Altima 2.5 S', '3500 Laramie', 'Gladiator Sport', 'F-150 FX4',
             'CX-9 Grand Touring', '550 Gran Turismo i', 'Pilot EX', 'Escalade Sport Platinum', 'Mustang V6 Premium',
             'Ghibli Base', 'F-350 King Ranch', 'Macan Base', 'Santa Cruz 2.5T Limited',
             'Rover LR4 HSE LUX Landmark Edition', 'Genesis Coupe 2.0T R-Spec', 'Expedition EL XLT', 'Camry Solara SE',
             'Sequoia SR5', 'Panamera 4', 'Corvette Stingray w/1LT', 'Rainier CXL', 'Pilot Elite', 'Sonata Hybrid Base',
             'M240 i xDrive', 'Rover Range Rover Evoque Base', '435 Gran Coupe i', 'Tacoma SR5', 'Silverado 1500 Base',
             'C-Class C 250 Luxury', 'Romeo Giulia Ti', 'Enclave Leather', 'Maxima SV', 'XT5 Luxury', 'Sorento LX',
             'Express 1500 Work Van', 'Q50 Premium', 'Tiguan 2.0T SE', 'MKX Reserve', 'Titan S', 'Murano SV',
             '911 Carrera S Cabriolet', 'Expedition Max Limited', 'Rover Range Rover P525 HSE SWB',
             'TLX Type S w/Performance Tire', 'Expedition Max XLT', 'Express 3500 LT',
             'Rover Range Rover Sport Supercharged Dynamic', 'Escalade Platinum Edition', 'Panamera 2',
             'Rover Discovery LSE', 'Rover Range Rover Evoque SE Premium', '335 i', 'RX 330 Base',
             'Ascent Touring 7-Passenger', 'TLX A-Spec', 'E-Class E 400', 'Bronco Outer Banks',
             'Impreza Outback Sport Wagon', 'F-150 XLT SuperCab', 'Highlander Hybrid Limited Platinum', '1500 SLT',
             'QX80 Base', 'Silverado 3500 LTZ', '300 Touring', '4Runner Trail', 'Camry Hybrid XLE', 'Tacoma SR',
             'Outback 3.6R Limited', 'Charger R/T 392', 'Rover Discovery Sport HSE', '2500 Tradesman',
             'Huracan EVO Base', 'Silverado 1500 W/T', 'M550 i xDrive', 'S4 3.0T Premium', 'Huracan EVO Coupe',
             'QX60 AUTOGRAPH', 'Rover Range Rover Sport HST MHEV', 'RSX Type S', 'Expedition Platinum',
             'Veloster Value Edition', 'Rover Range Rover Sport SE MHEV', 'Outback Touring XT', 'CX-9 Touring',
             'CT5-V V-Series', 'Rover Range Rover Sport 3.0L Supercharged HSE', 'Supra A91 Edition', 'GR86 Premium',
             'EcoSport SES', 'Cruze LT', 'ALPINA B7 ALPINA B7 xDrive', 'Cayenne S', 'Escalade ESV Base', 'Tucson SE',
             'Maverick XL', 'E250 Cargo', 'FJ Cruiser Base', 'Quattroporte S', 'Panamera Turbo', 'LX 600 F SPORT',
             'Z4 2.5i', 'CT 200h Premium', 'Cherokee Sport', 'ATS 2.0L Turbo', 'AMG GLE AMG GLE 63 S-Model 4MATIC',
             'LS 460 Base', 'RX 450h F Sport', 'Tahoe LTZ', 'Cruze LTZ', 'XT5 Premium Luxury', 'Wrangler SE',
             'A5 2.0T Premium Plus', 'Utility Police Interceptor Base', 'M3 Competition', 'FX50 Base', 'QX56 Base',
             '530 i xDrive', 'Pathfinder S', '911 Carrera 4 GTS', 'Cayman GT4', 'Sprinter 3500XD High Roof',
             'SRX Standard', 'Outlander SEL', '1500 Classic Warlock', 'Terrain SLT', 'Mazda3 i SV', 'Frontier SL',
             'Q5 S line Premium Plus', 'Focus SEL', 'Escalade ESV Luxury', 'Yukon Denali Ultimate', 'Acadia SLE-1',
             'Silverado 1500 LT', 'Suburban 1500 LT', 'F-150 XL', 'Tundra TRD Pro', 'Ram 2500 SLT Mega Cab',
             'Sierra 1500 SLE', 'Avalon Limited', 'Titan XD SV', 'R8 5.2 V10 plus', 'G80 3.8', 'Sienna LE', 'TSX Base',
             'Camaro ZL1', 'Golf R 20th Anniversary Edition', 'Sportage Plug-In Hybrid X-Line', 'G37 x',
             'S7 2.9T Prestige', 'Sonic LT', 'Mazda3 s Sport', 'A6 2.0T Premium Plus', 'C-Class C 63 AMG',
             'GLA 250 Base 4MATIC', 'GLE 350 Base 4MATIC', 'CTS 2.0L Turbo Luxury', 'MDX 3.7L Advance', 'Edge Sport',
             '911 Carrera GTS', 'Rover Range Rover P400 SE SWB', '350Z Touring', 'TLX PMC Edition',
             'Sierra 1500 Denali Ultimate', '718 Spyder Base', 'A8 L 4.0T', 'AMG GLE 63 S Coupe 4MATIC',
             'Impreza WRX Sti Special Edition', 'Acadia SLE-2', 'Mazda6 Grand Touring Reserve',
             'Escalade Premium Luxury', 'M2 Competition', 'K5 GT-Line', '325 i', 'WRX STI Base', 'E350 Super Duty Base',
             'Jetta SportWagen SE', 'CLS-Class CLS 63 AMG S-Model 4MATIC', 'Pathfinder Silver', 'GL-Class GL 450',
             '435 i xDrive', 'Cayenne Platinum Edition', 'G70 3.3T Advanced',
             'Rover Range Rover Sport 5.0L Supercharged Dynamic', 'M2 CS', 'Golf GTI 2.0T Autobahn 4-Door',
             'SLK-Class SLK280 Roadster', 'Rover Range Rover Evoque S', 'Challenger SRT8', 'SL-Class SL550 Roadster',
             'AMG E 53 Base 4MATIC', 'Cooper Base', '911 R', 'CTS 3.6L Premium Luxury', 'A6 55 Premium Plus',
             'Quattroporte Base', 'i3 Base w/Range Extender', 'ProMaster 3500 High Roof', 'MKX Black Label',
             'Veloster Turbo R-Spec', 'LS 430 Base', 'Silverado 1500 Limited Custom', 'Gallardo LP560-4', 'Sonata SE',
             'Grand Cherokee Laredo', 'Challenger R/T', 'Aventador S Base', 'Prius v Three', 'S2000 CR',
             'RX 450h F Sport Handling', 'Bentayga Speed', 'Odyssey LX', 'Aventador SVJ Base', '86 Base',
             '812 Superfast Base', 'SQ7 4.0T', 'F-250 Limited', 'Grecale Modena', 'Jetta 1.4T S', 'Q8 55 Premium Plus',
             'Titan SE', 'M56 Base', 'Malibu 1LT', 'GS 350 F Sport', 'Panamera 4 Edition', 'Express 2500 Work Van',
             'Wrangler Unlimited 4xe Sahara', 'G80 2.5T', 'Z3 3.0i Roadster', 'Camry XSE', 'Q50 Hybrid Premium',
             'Levante Modena', 'TLX V6 Tech', 'Traverse Premier', 'ATS 3.6L Luxury', 'Tahoe Premier', 'M850 i xDrive',
             'XC60 T6 Inscription', 'Santa Fe GLS', 'C-Class C300 4MATIC', 'Q7 45 Premium Plus', 'Mazda3 Touring',
             'Legacy 2.5 i Premium', 'Panamera GTS', 'Panamera Edition', 'Ram 2500 ST', 'IS-F Base',
             'Eclipse Spyder GS', 'Palisade Calligraphy', 'MKX Base', '135 i', 'Cooper S Clubman Base', 'RL Technology',
             'Armada LE', 'Martin Vantage Base', 'GX 460 Luxury', 'Prius Two', 'F-PACE SVR', '440 Gran Coupe i',
             'Celica GT', 'Sprinter Normal Roof', 'Rover Range Rover HSE', 'Yukon SLE', 'Huracan LP580-2S',
             'Martin V8 Vantage Base', 'TLX V6 Advance', 'Rover Range Rover Westminster SWB', 'Countryman Cooper S',
             'Sorento Hybrid EX', 'Rover Range Rover P400 SE LWB 7 Seat', 'ZDX Base', 'Lancer GTS', 'Mustang Base',
             'G 550 4x4 Squared Base', 'MX-5 Miata Grand Touring', 'Crosstour EX-L', 'Sequoia TRD Pro', 'Ram Van 1500',
             '300M Base', 'Sorento EX', '300 S', 'S6 4.0T', 'MKT Base', 'Rover Range Rover SWB', 'Navigator Base',
             'Town & Country LX', 'Traverse High Country', 'Sky Base', 'IS 350 F Sport', 'AMG GLE 43 4MATIC Coupe',
             'CX-5 Grand Touring', 'MX-5 Miata Club', 'M4 Competition', 'Crosstrek 2.0i Limited', 'Compass Limited',
             'Bentayga Azure First Edition', 'Murcielago Base', 'M-Class ML 350 4MATIC', 'AMG GLA 45 Base 4MATIC',
             'Rover Range Rover Supercharged', 'Corvette Stingray', 'Liberty Limited', 'AMG GT C',
             'E-Class E 300 4MATIC', 'Air Grand Touring', 'Frontier SE Crew Cab', 'Impreza 2.0i',
             'CX-30 2.5 S Select Package', 'Corvette Z06', 'Lancer Evolution MR', 'Beetle 1.8T', 'SLK-Class SLK320',
             'AMG GT AMG GT', 'S4 3.0 Prestige', 'RSX Base', '750 i', 'Colorado Z71', '350Z NISMO', 'Touareg TDI Lux',
             'SL-Class SL63 AMG Roadster', 'Veloster Base', 'Escalade Premium Luxury Platinum',
             'MDX 3.5L w/Technology Package', 'Titan SL', 'GS 350 Base', 'A7 55 Premium', 'Acadia Denali', 'S40 T5',
             'Corolla LE', 'Continental GT Speed', '4Runner Limited', 'Bronco Badlands Advanced', 'Blazer Premier',
             'CT6-V 4.2L Blackwing Twin Turbo', 'S-Class S 65 AMG', 'Titan SV', 'AMG S 63 Base 4MATIC',
             'Silverado 1500 ZR2', 'CLS-Class CLS500', 'CR-V Touring', 'ILX Technology Plus Package',
             'ATS 2.0L Turbo Luxury', 'S5 3.0T Prestige', 'CC 2.0T Sport', 'Escape SE', 'AMG GLC 63 Base 4MATIC',
             'Colorado LT Crew Cab', '1500 Cheyenne Extended Cab', 'WRX Premium', 'X4 M Competition', 'Macan',
             'Avalon Touring', 'Sorento LX V6', 'E-Class E 550 4MATIC', 'Mazda3 FWD w/Preferred Package', 'Accent GL',
             '911 Carrera 4', 'Telluride EX', 'Traverse RS', 'Envision Preferred', 'Charger SRT Hellcat Widebody',
             'Excursion Limited Ultimate', 'Continental Reserve', 'Santa Fe SE', 'S80 T6', 'Rogue SL',
             'Rover Defender X-Dynamic SE', 'M3 Competition xDrive', 'MX-5 Miata RF Grand Touring', 'Versa 1.8 S',
             'XT6 Premium Luxury AWD', 'Liberty Renegade', 'Civic Si', 'Wrangler Rubicon Hard Rock', 'Odyssey EX-L',
             'Atlas 3.6L SEL Premium R-Line', 'E-PACE 300 Sport', 'Z4 sDrive28i', 'AMG C 43 AMG C 43 4MATIC',
             'FX37 Base', 'Challenger SRT Demon', 'CX-50 2.5 Turbo Premium Package',
             'Escalade ESV Premium Luxury Platinum', 'Armada SL', 'M440 i', 'Armada Platinum', 'G80 3.3T Sport',
             'MazdaSpeed3 Grand Touring', 'Navigator L Reserve', 'Xterra Pro-4X', 'CC Sport', 'R8 5.2 V10 performance',
             'Bronco', 'S8 4.0T Plus', 'Continental GT W12', 'CX-90 Premium', '640 Gran Coupe i xDrive',
             'Bronco Heritage Edition Advanced', 'LaCrosse CX', 'XC90 T6 Inscription', '911 Carrera C4S',
             'Rover Range Rover Sport SVR Carbon Edition', 'Bronco Sport Outer Banks', 'Camry XLE',
             'Cayenne E-Hybrid S Platinum Edition', 'Outback 2.5i Premium', '330e iPerformance',
             'MDX w/Technology Package', 'Odyssey Elite', 'Suburban RST', 'Optima EX', 'Routan SE', 'Commander Base',
             'Huracan LP610-4', 'Cascada Base', 'LaCrosse Base', 'Bentayga Onyx Edition', 'M37 x',
             'A4 2.0T Titanium Premium', 'A7 3.0T Premium', 'CX-7 Grand Touring',
             'Rover Range Rover Velar P380 SE R-Dynamic', 'A7 55 Premium Plus', 'S60 T6 Momentum',
             'Mazda6 Carbon Edition', '300 Base', 'Evora 2+2', 'GTI Base', 'Gallardo SE', 'Aviator Reserve AWD',
             'GLC 300 GLC 300', 'Cherokee X', 'XTS Luxury', 'Forester Premium', 'Express 1500 Cargo',
             'A4 2.0T Premium Plus quattro', 'Juke SL', 'LaCrosse Leather', 'Colorado ZR2', 'CTS Premium',
             'Romeo Stelvio Ti', '1500 Sport', 'E150 XLT', 'Rover Range Rover 5.0L Supercharged Autobiography',
             '718 Boxster S', 'X7 xDrive40i', 'BRZ Premium', 'Juke SV', 'Q50 3.0t Signature Edition', 'Optima SX Turbo',
             'Tahoe LS', 'F-250 XLT Crew Cab Super Duty', '640 Gran Coupe i', 'Wrangler Unlimited Rubicon 392',
             '488 GTB Base', 'Blazer 1LT', 'Silverado 1500 Custom Trail Boss', 'Terrain SLT-1', 'FR-S Monogram',
             'Express 1500 Base', 'Santa Fe SEL Plus 2.4', 'MDX Sport', 'F-250 Base', 'S-Class S 450 4MATIC',
             '430 Gran Coupe i xDrive', 'ForTwo Pure', 'TT 2.0T Premium', 'Forester 2.5 X', 'Charger GT',
             'M6 Gran Coupe Base', 'Eclipse Spyder GT', 'A6 3.2 quattro', 'ProMaster 3500 Tradesman',
             'C30 T5 Premier Plus', 'Silverado 1500 LT Extended Cab', 'GV80 2.5T', 'Civic Sport', 'Panamera S',
             'NX 200t Base', 'Solstice Base', 'Model Y Performance', 'Tundra Platinum', 'GTC4Lusso T', '323 Ci',
             'Rover LR4 Lux', 'Impreza WRX Premium', 'CR-V LX', 'S60 R', 'Rover Range Rover Velar P250 SE R-Dynamic',
             'S7 4.0T Premium Plus', 'Integra LS', 'GLA-Class GLA 45 AMG', 'i8 Base', 'Prius Plug-in Base',
             'NV Passenger NV3500 HD SV V8', 'Bentayga S', 'XK Base', 'Explorer sport', 'Quest SL', 'Taurus SHO',
             'Tundra SR', 'Mazda3 i Sport', 'Kicks S', 'Phantom', '4Runner TRD Off Road', '911 Turbo Cabriolet',
             'GLA-Class GLA 250 4MATIC', 'Flex Limited', 'Silverado 1500 Limited High Country', '370Z Touring',
             'Mustang Mach-E GT', 'MKZ Select', 'QX60 Pure', 'Sprinter 3500 High Roof', 'Panamera Platinum Edition',
             'C-Class C55 AMG Sport', 'RS Q8 4.0T', 'Aventador LP750-4 Superveloce', 'Grand Cherokee L Summit',
             'G6 GTP', '718 Boxster Base', 'Romeo Giulia Quadrifoglio', 'ProMaster 2500 High Roof', '428 i xDrive',
             'MKZ Hybrid Base', 'Encore GX Essence', 'M4 CS', 'RX-8 R3', 'S3 2.0T Premium Plus', 'S8 4.2 quattro',
             'Huracan LP580-2', 'CR-V EX', '650 i', '370Z Base', 'Tacoma Base', 'XF 35t R-Sport', 'Fiesta ST',
             'MX-5 Miata RF Club', 'Bronco Raptor', 'X6 M50i', 'Bronco Base', 'Cayenne Turbo GT', 'QX80 SENSORY',
             'GT-R Black Edition', 'G35 Base', 'X1 sDrive28i', 'Silverado 1500 LTZ', 'Supra 3.0 Premium',
             'C-Class C 250 Sport', 'Trailblazer SS', 'Challenger GT', 'Boxster GTS', 'Cruze LS', 'RS 4 4.2 quattro L',
             'Express 3500 Base', 'SC 430 Base', 'Impreza 2.0i Sport', 'Santa Fe Sport 2.0L Turbo Ultimate',
             'Palisade SEL', 'Tahoe Base', 'GranTurismo MC', 'ES 330 Base', 'TL Technology', 'CX-30 Base',
             'Jetta 1.4T R-Line', 'Outback Limited', 'Venza XLE', 'Expedition King Ranch',
             'Silverado 1500 Limited LT Trail Boss', 'Fusion Hybrid Base', 'CT5 Premium Luxury', 'GV70 2.5T',
             'Rover Range Rover Velar SVAutobiography Dynamic Edition', 'XC90 Hybrid T8 Inscription', 'Cayenne AWD',
             'Sonata Sport 2.0T', 'Ram 2500 Quad Cab', 'R8 5.2 quattro Spyder', 'Q70 3.7X', 'Excursion XLT 4WD',
             'Mazda3 Grand Touring', 'Charger Base', 'Grand Cherokee L Overland', 'Arnage R', 'Martin DBS Superleggera',
             'Monte Carlo Supercharged SS', 'Rover LR2 HSE', 'Roma Base', 'Wraith Base', 'RAV4 SE', '650 i xDrive',
             'Rover Range Rover 3.0L Supercharged', '200 C', 'F-250 XL', 'Fusion Hybrid SE Hybrid', 'Mustang Bullitt',
             'X6 M Base', 'CX-9 Touring Plus', 'CLK-Class 500 Cabriolet', 'Bentayga V8', 'Vue Hybrid Base', '325 Ci',
             '640 i', 'Ranger Sport SuperCab', 'Titan XD S', 'Elantra SE', '540 i', 'S5 3.0 Premium Plus',
             'Civic Si Base', 'ATS 2.5L', 'RAV4 Base', 'Compass High Altitude', 'A3 2.0 TDI Premium Plus',
             '911 Targa 4 GTS', 'SLK-Class SLK230 Kompressor', 'XJ Vanden Plas', 'Elise Base', 'DTS Luxury',
             '4Runner Venture Special Edition', 'G90 3.3T Premium', 'K5 EX', 'Telluride EX X-Line', 'E-Class E500',
             'TLX Base', 'Martin DBX Base', 'Tahoe RST', 'XC90 Recharge Plug-In Hybrid T8 Inscription 7 Passenger',
             'G70 2.0T', 'Explorer Sport Trac XLT', 'GLE 350 GLE 350', 'Sierra 1500 AT4', 'XC70 3.2',
             'Genesis Coupe 3.8 Grand Touring', 'Altima 2.5 SV', 'F-350 XL', 'Avalanche LTZ',
             'Silverado 2500 High Country', 'Charger R/T', 'ILX Premium & A-SPEC Packages',
             'Grand Cherokee WK Laredo X', 'Silverado 1500 Z71 Extended Cab', 'LS 500 Base', '2500 SLT',
             'Ridgeline Black Edition', 'Rover LR3 HSE', 'Sierra 3500 SLE', 'Flying Spur V8',
             'Sorento Plug-In Hybrid SX', 'C-Class C 300 4MATIC Luxury', 'A6 45 Premium Plus', 'F-150 Tremor',
             'AMG G AMG G 63 4MATIC', 'Maybach S 580 4MATIC', 'ALPINA B7 Base', 'Golf SportWagen TSI SE',
             'Gallardo Base', 'Q7 3.0T Premium', 'Bolt EV LT', 'F-PACE 35t Premium', 'RX-8 Sport', '740 Li',
             'Avalanche 1500 LT', 'Pacifica Launch Edition', 'Ranger Edge SuperCab', 'Acadia SLT-2',
             '4Runner Limited Nightshade', 'F-PACE 25t Premium', '2500 Laramie', 'TSX 2.4', '430 i xDrive',
             'MDX Technology', 'Ranger XLT SuperCab', 'RDX Advance Package', 'Sorento Plug-In Hybrid SX Prestige',
             'Forte Koup EX', 'Escalade Sport', 'GL-Class GL 550 4MATIC', 'F-250 LARIAT', '440 i xDrive',
             'Boxster Black Edition', 'Lancer Evolution Base', 'Silverado 2500 WT', 'Golf GTI 2.0T Autobahn',
             'X4 xDrive30i', 'F-250 XLT Super Duty', 'ATS 2.5L Luxury', 'A4 2.0T Premium Plus', 'Revero Base',
             'Montero Limited', 'A4 3.2 Premium Plus quattro', 'NX 300h Base', 'Suburban 2500 LS', 'AMG GT Base',
             'XF 3.0 Portfolio', 'MDX 3.5L w/Advance & Entertainment Pkgs', 'Rover Discovery HSE',
             'Ram 1500 SLT Mega Cab', 'Rover Range Rover 5.0L Supercharged', 'X6 xDrive40i', 'R8 5.2 V10',
             'X5 xDrive50i', 'Durango SRT', 'Excursion Limited 4WD', 'Rover Range Rover Sport SVR',
             'Sierra 1500 SL Crew Cab', 'RAV4 TRD Off Road', 'A7 Premium Plus', 'Rover Range Rover Autobiography',
             'Quattroporte S GranLusso', 'Stinger GT2', 'Genesis 4.6', 'Stinger GT1', '4Runner Sport', 'AMG C AMG C 63',
             'E-Class E 450 4MATIC', 'Q70h Base', 'S90 T5 Momentum', 'Highlander Hybrid XLE', 'Fit Sport',
             'Wrangler Unlimited X', '911 Carrera 4 Cabriolet', '718 Cayman GTS', 'Renegade Trailhawk', 'F-150 Limited',
             'M5 Competition', 'Tacoma TRD Pro', 'G8 GT', 'Tacoma TRD Sport', 'F-TYPE S', 'X5 xDrive35i',
             'tC Release Series 6.0', 'Escalade Luxury', 'CX-30 Preferred', 'Bronco Sport Base', 'X6 xDrive50i',
             'Sentra SR', 'S-Class S 550', 'Dart SE', 'New Compass Trailhawk', 'Arteon 2.0T SEL Premium R-Line',
             'Lancer DE', 'Corvette Z06 w/2LZ', '1500 Classic Tradesman', 'Jetta GLX VR6', 'F-150 Lariat SuperCrew',
             'Bentayga Activity Edition', 'Ghibli S GranLusso', '488 Spider Base', 'Aventador LP700-4', 'Z4 sDrive35is',
             '428 i', 'XC90 Hybrid T8 R-Design', 'Panamera Base', 'Challenger R/T Scat Pack', 'DTS Luxury II',
             'Accord Crosstour EX-L', 'CT4 Luxury', 'Town & Country Touring', 'Compass Latitude', 'Corolla CE',
             'TSX Technology', 'Sierra 2500 SLE H/D Extended Cab', 'Maxima GLE', 'Charger SRT Hellcat',
             'Gladiator Mojave', 'Trailblazer RS', 'Grand Wagoneer Base', 'Camry Hybrid LE', 'Yukon XL AT4',
             'SL-Class SL 63 AMG', 'Wrangler Rubicon', 'C-Max Energi SE', '750 750i xDrive', 'Legacy 2.5i Premium',
             'Touareg VR6 Lux', 'MDX Touring', 'Rover Discovery SE', 'Q3 45 S line Premium Plus',
             'Tundra Hybrid TRD Pro', '4Runner 4WD', 'Seltos S', 'QX30 Premium', 'Accord Hybrid Base',
             'Rover Range Rover Evoque R-Dynamic HSE', 'Juke NISMO RS', 'Navigator Premiere', 'HS 250h Premium',
             'AMG GL AMG GL 63 4MATIC', 'Charger SRT8', 'Gladiator Freedom', 'Rover Range Rover 5.0L V8 Supercharged',
             'SL-Class SL600 Roadster', 'Silverado 2500 H/D', '370Z NISMO Tech', 'Sierra 3500 Denali', 'GTO Base',
             'Enclave Avenir', 'i3 120Ah w/Range Extender', 'xB Base', 'Prelude Type SH', 'ES 250 Base',
             'Continental GT GT Speed', 'Q5 3.0 TDI Premium Plus', 'Avalon XLS', 'Traverse LS', 'Avenger SE',
             'F-TYPE S British Design Edition', 'Silverado 1500 High Country', 'XC60 T5 R-Design',
             'F-350 Lariat Crew Cab Super Duty DRW', '200 Limited', 'Rover Range Rover SV Autobiography Dynamic SWB',
             'RX 350 F SPORT Appearance', 'Challenger SRT8 392', 'GR Corolla Circuit Edition', 'New Beetle GLS',
             'Shelby GT350 Base', 'TT Roadster quattro', 'Grand Wagoneer Series III', 'XE 25t', 'AMG GLE 53 AMG GLE 53',
             'AMG GT R', '428 Gran Coupe i xDrive', 'RS Q8 4.0T quattro', 'Sorento S', 'C-Class C 300 Luxury',
             'Lancer Sportback ES', 'NX 350h Premium', 'Bronco Big Bend', 'A4 2.0T Tech Premium', '911 Carrera Turbo',
             'TLX Tech', 'LX 470 Base', 'GLB 250 Base 4MATIC', 'ILX 2.0L w/Premium Package', 'Escape PHEV SE',
             'TT RS Base', '228 i', 'Passat 2.5 SE', '4Runner TRD Pro', 'Tahoe High Country', 'RAV4 Hybrid XLE',
             'Q50 3.0T Premium', 'Q3 S line Premium Plus', 'Maverick Lariat', 'Malibu Premier', 'X5 M Base',
             'Tundra Grade', 'Arteon SEL R-Line', 'AMG GLC 43 AMG GLC 43', 'Mustang Shelby GT500', '570S Base',
             'TT RS 2.5T', 'GLE 350 Base', 'RX 300 4WD', 'FF Base', 'Outback 3.6R Touring', 'R1S Launch Edition',
             'Challenger SE', '525 i', 'SLS AMG Base', 'RX 350 Crafted Line F Sport', 'LX 600 Premium',
             'Optima Hybrid LX', 'Flex SEL', 'Eclipse GS', '840 Gran Coupe i xDrive', 'Q5 S line Premium',
             'Jetta 1.4T SE', 'LX 570 Base', 'Gallardo LP570-4 Superleggera', 'Gladiator Willys', 'Maybach S S 600',
             'S-Class S 560', 'XC90 3.2 Premier Plus', 'Golf SportWagen TSI S 4-Door', 'Grand Cherokee Summit',
             'Mustang Boss 302', 'Silverado 1500 LS', 'Urus Pearl Capsule', 'Eos 2.0T', 'Ridgeline RTL-E',
             'Elantra N Base', 'RS 3 2.5T', 'Cayman GTS', 'Pathfinder Platinum', 'Passat 2.0T R-Line', 'TL 3.7',
             'Supra A91-MT Edition', 'Terrain Denali', '840 i xDrive', 'S60 T5 Premier Plus', 'Dakota Sport',
             '500 Sport', '1500 TRX', 'MX-5 Miata Sport', 'SX4 Base', 'Ram 1500 Laramie', 'Niro Plug-In Hybrid EX',
             'Atlas 3.6L SEL Premium', 'CX-7 Sport', 'Jetta GLI', 'Q8 55 Premium', 'Q40 Base', 'Highlander Base',
             'Taycan Base', 'Rover Discovery Sport SE R-Dynamic', 'Impreza WRX Base', 'Escalade ESV Platinum Edition',
             'Charger SE', '320 i xDrive', 'Taurus X Limited', 'California T', 'Yukon XL 1500 SLT', 'Colorado Z85',
             'Lancer Evolution GSR', '718 Cayman S', 'XC90 3.2', 'Impala 2LZ', 'Navigator L', 'Palisade Limited',
             'Challenger SXT', 'Escape Limited', 'Passport TrailSport', 'Viper GTC', 'Panamera 4 Platinum Edition',
             'Silverado 3500 High Country', 'ALPINA B7 xDrive', 'Pickup Truck XE', 'A3 2.0T', '740 iL',
             'Golf GTI 2.0T S 4-Door', 'Z4 3.0si', 'Fusion Hybrid Titanium', 'F-250 XL Crew Cab Super Duty',
             'Niro EV EX', 'Canyon Denali', 'Mark LT Base', 'Genesis Coupe 2.0T', '530 i', 'Tundra Hybrid Limited',
             '2500 Powerwagon', 'Ram 1500 Quad Cab', 'RS 5 4.2', 'Martin DB7 Vantage Volante', 'Wrangler S', 'E-PACE S',
             'Touareg V6 Executive', 'STS V6', 'Optima Hybrid EX', 'Savana 2500 Work Van', 'tC Anniversary Edition',
             'Mazda3 FWD w/Premium Package', 'Impala 1LT', 'Grand Cherokee Altitude', 'Magnum Base',
             'Malibu Limited LT', 'F-350 Lariat Super Duty Crew Cab', 'Rover Range Rover Evoque SE', 'G-Class G 63 AMG',
             'R8 Base', 'TLX Type S PMC Edition', 'Beetle 2.0T S', '500X Trekking Plus', 'XTS Premium',
             'Sierra 2500 AT4', 'SQ8 4.0T Premium Plus', 'RDX Technology Package', 'Q70 3.7', '718 Boxster GTS',
             'R8 4.2 quattro Spyder', 'MC20 MC20', 'Equinox Premier w/2LZ', 'Silverado 2500 LTZ H/D Extended Cab',
             'Veyron 16.4 Grand Sport', 'Golf R 4-Door w/DCC & Navigation', 'S6 4.0T Premium Plus', 'Yaris Base',
             'Outback 2.5 i Special Edition', 'Accent GLS', '4Runner Venture', 'Transit-250 Base', 'A8 4.0',
             'Armada SV', 'Sportage X-Pro', 'Convertible Cooper', 'SLC 300 Base', 'F-150 Lightning LARIAT',
             'Escape SEL', 'Explorer Sport', 'Silverado 1500 Hybrid 1HY', 'F-PACE S', 'V60 Cross Country T5',
             'RAV4 Prime XSE', 'LS 500 F Sport', 'RX 450h F SPORT Handling', 'Malibu LTZ', 'S4 Base', 'X7 xDrive50i',
             'Caprice Classic Base', 'H2 SUT', 'RC 350 F Sport', 'MX-5 Miata Shinsen', 'XE 20d Prestige', 'Magnum R/T',
             'Q8 3.0T Premium', 'Cruze LT Automatic', 'MDX Sport Hybrid 3.0L w/Technology Package', 'Mazda6 iSport VE',
             'Challenger SRT 392', 'Q3 2.0T Premium Plus', 'Evora Base', 'X3 sDrive30i', 'Escalade ESV Premium Luxury',
             'Edge SE', 'G37 Sport', 'Silverado 2500 LTZ', 'Rover Range Rover P530 SE', 'Encore Preferred',
             'Matrix XRS', 'G35 Sport', 'M-Class ML 350', 'X5 M50i', '3500 Tradesman', 'Forte LX',
             'Bentayga W12 Signature', 'Highlander Hybrid Limited', '228 Gran Coupe i xDrive', 'XKR Base',
             'RX 350 RX 350 F SPORT Handling', 'Sorento EX V6', 'X6 sDrive35i', 'Huracan Tecnica Coupe', 'NV200 SV',
             'CT5-V Blackwing', 'XJ8 Base', 'CTS 3.6L Luxury', 'Forte LXS', 'i3 94 Ah', 'Ram 2500 SLT Quad Cab',
             'Thunderbird Premium', 'Q5 3.0T Premium Plus', 'Genesis 5', 'NX 350 F SPORT Handling', '135 is',
             'Z Proto Spec', 'F-150 Heritage XL SuperCab Flareside', 'Bronco Badlands', 'Verano Convenience',
             'Transit-350 XL', 'Lancer Evolution IX', 'TT 3.2 Cabriolet quattro', 'Arteon 2.0T SE',
             'Canyon Elevation Standard', 'i3 Base', 'Levante S', 'X3 M40i', 'Tiguan 2.0T SEL Premium R-Line',
             'Impala Base', 'Corolla S Plus', 'Rogue SV', 'Atlas 3.6L SE w/Technology', 'Q7 Premium Plus',
             'Niro Plug-In Hybrid EX Premium', 'NSX Base', 'Macan Turbo', 'Phantom Drophead Coupe Drophead',
             'S-Class S 450', 'Maverick XLT', 'Cayenne E-Hybrid S', 'Lucerne CXL', 'Sierra 1500 Limited Elevation',
             'Corolla iM Base', 'Sportage SX Turbo', 'TT 1.8L', 'F430 Berlinetta', 'A5 Sportback S line Premium Plus',
             '9-3 SE', 'GR86 Base', 'Compass Trailhawk', 'Optima S', 'Mustang EcoBoost', 'Accent SEL', 'CT 200h Base',
             'Mustang Mach-E Premium', 'E-Class E55 AMG', 'Corsair Standard', 'Golf Alltrack TSI SE',
             'Rover Defender X', '325 xi', 'Highlander Platinum', 'Golf GTI 2.0T SE w/Performance Package 4-Door',
             'Rover Defender', '550 i xDrive', 'Navigator Select', 'E-Class AMG E 53', 'XE 35t Premium', 'Rogue S',
             '750 Li', 'Avalon Hybrid XLE Premium', 'XF 35t Prestige', '535 i', 'Explorer Timberline',
             'Wrangler 80th Anniversary', 'Corsair Grand Touring', 'CLS-Class CLS 400 4MATIC',
             'MDX 3.5L Technology Package', 'Maxima SL', 'Escalade Base', 'Sportage S', 'Colorado LT', 'tC Base',
             'C-Class C280 4MATIC', 'A6 3.0 TDI Premium Plus', 'RLX Advance Package', 'Pacifica Hybrid Touring L',
             'Grand Caravan R/T', 'XF XFR-S', 'F-350 XLT', 'Marauder Base', 'Regal Turbo - Premium 1',
             'Q5 2.0T Premium', 'Tundra 1794', 'Enclave 1XL', 'Sienna XLE Limited', 'Patriot Latitude',
             'Corsair Reserve', 'DTS Base', '4Runner TRD Sport', 'XF Luxury', 'Golf R Base', 'X7 M50i',
             'SL-Class SL400', '650 Gran Coupe i', 'Z4 2.5i Roadster', 'G37 Journey', 'Pilot Black Edition',
             'Q3 45 S line Premium', 'Fusion Energi Titanium', 'Genesis Coupe 3.8 R-Spec', 'EQS 450+ Base',
             'Terrain SLE', 'Versa 1.6 SL', 'Romeo Stelvio Quadrifoglio', 'Cube 1.8 S', 'Carrera GT Base',
             'Ranger Lariat', 'TTS 2.0T Premium Plus', 'Accord Sport', 'Trax LS', 'Civic Type R Touring', 'Tucson SEL',
             'AMG E 53 4MATIC', 'Evora 400 Base', 'Continental GT V8 First Edition',
             'Rover Discovery Sport S R-Dynamic', 'R-Class R 350 4MATIC', '500 Lounge', 'X5 sDrive35i',
             'Sprinter 4500 High Roof', 'GLC 300 Base', 'A5 2.0T Prestige', 'Z4 3.0i Roadster',
             'Atlas Cross Sport 3.6L V6 SEL Premium', 'R1S Adventure Package', 'MazdaSpeed Miata MX-5 Base',
             'TLX w/A-Spec Package', 'Quattroporte Sport GT', 'Pacifica Touring', 'SLK-Class SLK 250',
             'Highlander LE Plus', 'RS 4 Base', 'e-tron Prestige', 'Telluride LX', 'Coupe Cambiocorsa',
             'Crosstrek 2.0i Premium', 'RDX', 'Outback 3.0 R VDC Limited', 'Tundra Hybrid Capstone', 'Rogue Sport S',
             'Dakota SLT', 'NV200 S', 'S60 B5 Inscription', 'F-TYPE V6 S', 'Hardtop Cooper', 'MKS Base', 'X2 xDrive28i',
             'XC40 T5 Momentum', 'XC60 Recharge Plug-In Hybrid T8 Inscription', 'Baja Base', '3500 SLT',
             'Boxster RS 60 Spyder', 'RDX w/Advance Package', 'XT4 Sport', 'RDX Base', 'Legacy 2.5 GT spec.B',
             'Sebring LX', 'Beetle 2.0T Final Edition SE', 'CLK-Class 550', 'SC 300 Base', 'SRX Performance Collection',
             '300ZX Base', 'Arteon 2.0T SEL R-Line', 'Quattroporte Modena Q4', 'AMG C 43 Base', 'S4 4.2 quattro',
             'Elantra GLS', 'Continental GTC V8', 'G-Class G 550', 'Caliber Express', 'Mazda6 i Grand Touring',
             'Bolt EUV Premier', 'Eclipse GT', 'Sierra 1500 SLE1 Extended Cab', 'Niro EX', 'XF S', 'Impreza Premium',
             'A5 45 S line Premium Plus', 'F-150 SVT Raptor', 'Mirage ES', 'RDX PMC Edition', 'Pathfinder SV',
             'Sierra 2500 SLE', 'Corolla Hybrid LE', 'Trailblazer LT', 'X3 M AWD', '230 i',
             '440 Gran Coupe 440i xDrive', 'Land Cruiser', 'Prius Touring', 'CT6 Luxury', 'Equinox 2LT',
             '2 Launch Edition', 'V60 T6 R-Design Platinum', 'Yaris L', '750 Li xDrive', 'Model S Plaid',
             'Passat 2.0T SE', 'Type 57 Base', 'Malibu LT', 'Ascent Limited 7-Passenger', 'Stinger GT', 'IONIQ 5 SE',
             'Rover Range Rover Sport First Edition', 'X6 xDrive35i', 'S5 4.2 Premium Plus', 'Model 3 Long Range',
             'X3 xDrive28i', 'Model X Base', '9-3 Aero', 'MKC Select', 'RDX w/A-Spec Package', 'LYRIQ Luxury',
             'S60 Recharge Plug-In Hybrid T8 Inscription', 'XJ Base', 'MC20 Base', 'Crosstrek Premium',
             'Ram 1500 SRT-10', 'Durango SLT', 'GT', 'RX 350 RX 350', 'SQ5 3.0T Premium', 'Integra GS-R',
             'Outlander Sport 2.4 SE', 'Roadmaster Estate', 'G70 3.3T', 'C-Class 4MATIC Sedan', '750 iL',
             'X5 xDrive40e', 'Accord Hybrid Touring', 'Kona N Base', 'Rio S', 'Model X Long Range', 'TLX',
             'Wagoneer Series II 4x4', 'Levante GTS', 'Santa Fe Sport 2.0L Turbo', 'F-TYPE', 'M760 M760i xDrive',
             '530e Base', 'Aviator Luxury', '300C SRT8', 'X5 xDrive 35i Sport Activity', '500e Battery Electric',
             '430 430i', 'Mustang Mach-E Select', 'X5 3.0i', 'Romeo Stelvio Base', 'Sonata Sport',
             'Sienna XSE 25th Anniversary', 'E-Class 400E', 'CLS 450 Base', 'F-150 Lightning XLT', 'EQS 450 4MATIC',
             'Bronco XLT', 'Protege DX', 'Elantra HEV Limited', 'Mirai Limited', 'S5 3.0T Premium', 'X4 M40i',
             'Clarity Plug-In Hybrid Base', 'XK R', '370Z NISMO', 'Passport Elite', 'Prowler Base', 'X5 3.0si',
             'MDX w/Advance Package', 'allroad 2.0T Prestige', 'GLS 450 Base', 'Q5 40 Premium', 'Countryman Cooper',
             'Model X 75D', 'Viper SRT-10', 'Model X Performance', 'Mazda3 s Grand Touring', 'Taycan Turbo',
             'Model S 90D', 'S-10 LS', 'C40 Recharge Pure Electric Twin Ultimate', 'Q4 e-tron 50 Premium Plus',
             '124 Spider Abarth', 'XLR V', 'Convertible John Cooper Works', 'Leaf SV PLUS', 'Kona EV SEL', 'XC60 3.2',
             '1500 Cheyenne', 'Tucson Hybrid SEL Convenience', 'GLE 450 GLE 450', 'E-Class D 2.5 Turbo',
             'X5 eDrive xDrive40e', 'Insight EX', 'Corvette ZR-1', 'X7 ALPINA XB7',
             'Rover Range Rover Sport 3.0 Supercharged HST', 'X3 xDrive35i', 'XLR Base', 'DeVille Base', 'Model S 70D',
             'Leaf S', '240SX Base', 'IONIQ Plug-In Hybrid SEL', '740e xDrive iPerformance', '330 330i xDrive',
             'Q5 Premium', 'Mustang Mach-E California Route 1', 'bZ4X Limited'])
        self.model_LE.setFixedSize(850, 30)
        model_layout.addWidget(self.label_model)
        model_layout.addWidget(self.model_LE)
        # 将具体类型选择区域的布局添加到主布局
        layout.addLayout(model_layout)

        # fuel_type_layout
        fuel_type_layout = QHBoxLayout()
        self.label_fuel_type = QLabel('燃料类型:')
        self.fuel_type_LE = QComboBox()
        self.fuel_type_LE.addItems(['Gasoline', 'E85 Flex Fuel', 'Hybrid',
                                    'Diesel', 'Plug-In Hybrid', 'not supported'])
        self.fuel_type_LE.setFixedSize(850, 30)
        fuel_type_layout.addWidget(self.label_fuel_type)
        fuel_type_layout.addWidget(self.fuel_type_LE)
        layout.addLayout(fuel_type_layout)

        # transmission_LE_layout
        transmission_LE_layout = QHBoxLayout()
        self.label_transmission = QLabel('变速器类型:')
        self.transmission_LE = QComboBox()
        self.transmission_LE.addItems(['Automatic', 'Other', 'Manual'])
        self.transmission_LE.setFixedSize(850, 30)
        transmission_LE_layout.addWidget(self.label_transmission)
        transmission_LE_layout.addWidget(self.transmission_LE)
        layout.addLayout(transmission_LE_layout)

        # accident_LE_layout
        accident_LE_layout = QHBoxLayout()
        self.label_accident = QLabel('是否损害:')
        self.accident_LE = QComboBox()
        self.accident_LE.addItems(['None reported',
                                   'At least 1 accident or damage reported'])
        self.accident_LE.setFixedSize(850, 30)
        accident_LE_layout.addWidget(self.label_accident)
        accident_LE_layout.addWidget(self.accident_LE)
        layout.addLayout(accident_LE_layout)

        # displacement_LE_layout
        displacement_LE_layout = QHBoxLayout()
        self.label_displacement = QLabel('发动机规格:')
        self.displacement_LE = QComboBox()
        self.displacement_LE.addItems(['Medium', 'Extra-large', 'Ultra-large', 'Large', 'Small'])
        self.displacement_LE.setFixedSize(850, 30)
        displacement_LE_layout.addWidget(self.label_displacement)
        displacement_LE_layout.addWidget(self.displacement_LE)
        layout.addLayout(displacement_LE_layout)

        # car_age_layout
        car_age_layout = QHBoxLayout()
        self.label_car_age = QLabel('汽车年龄:')
        self.car_age = QLineEdit()
        self.car_age.setFixedSize(850, 30)
        car_age_layout.addWidget(self.label_car_age)
        car_age_layout.addWidget(self.car_age)
        layout.addLayout(car_age_layout)

        # 创建一个按钮，用于提交信息
        self.submit_button = QPushButton('Submit')
        self.submit_button.clicked.connect(self.submit_info)
        layout.addWidget(self.submit_button)

        # 创建一个标签来显示输出信息
        self.output_label = QLabel()
        layout.addWidget(self.output_label)
        self.setLayout(layout)

        # 设置输出标签的样式
        self.output_label.setStyleSheet("QLabel{ background-color: #f0f0f0; font-size: 25px; text-align: center;}")
        self.output_label.setFixedSize(500,100)
        # 设置提交按钮的样式
        self.submit_button.setStyleSheet("QPushButton { background-color: green; color: white; }")
        self.submit_button.setFixedHeight(50)

    def submit_info(self):
        # 获取下拉列表中选择的值
        brand = self.brand_LE.currentText()
        model = self.model_LE.currentText()
        fuel_type = self.fuel_type_LE.currentText()
        transmission = self.transmission_LE.currentText()
        accident = self.accident_LE.currentText()
        displacement = self.displacement_LE.currentText()
        car_age = self.car_age.text()

        result = create_RandomForestRegressor(brand, model, fuel_type, transmission, accident, displacement, int(car_age))
        output_text = (f"汽车价格预测：{result}元")
        self.output_label.setText(output_text)


def create_RandomForestRegressor(brand, model, fuel_type, transmission, accident, displacement, car_age):
    model_train_data = pd.read_csv('data/model_train_data.csv')
    x = model_train_data[['brand_LE', 'model_LE', 'fuel_type_LE', 'transmission_LE', 'accident_LE', 'displacement_LE', 'car_age']]
    y = model_train_data['price']
    # 分割数据
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=15)
    # 分割数据
    rf_model = RandomForestRegressor(random_state=15, n_jobs=-1,
                                     max_depth=15, min_samples_split=10, n_estimators=200)
    rf_model.fit(x_train, y_train)
    brand = brand
    model = model
    fuel_type = fuel_type
    transmission = transmission
    accident = accident
    displacement = displacement
    car_age = car_age
    brand_LE = model_train_data[model_train_data['brand'] == brand].brand_LE.values[0]
    model_LE = model_train_data[model_train_data['model'] == model].model_LE.values[0]
    fuel_type_LE = model_train_data[model_train_data['fuel_type'] == fuel_type].fuel_type_LE.values[0]
    transmission_LE = model_train_data[model_train_data['transmission'] == transmission].transmission_LE.values[0]
    accident_LE = model_train_data[model_train_data['accident'] == accident].accident_LE.values[0]
    displacement_LE = model_train_data[model_train_data['displacement'] == displacement].displacement_LE.values[0]
    pre_df = {'brand_LE': [brand_LE],'model_LE': [model_LE],
              'fuel_type_LE': [fuel_type_LE],
              'transmission_LE': [transmission_LE],
              'accident_LE': [accident_LE],
              'displacement_LE': [displacement_LE],
              'car_age': [car_age],
              }
    pre_df = pd.DataFrame(pre_df)
    y_pred_log = rf_model.predict(pre_df)
    return int(y_pred_log[0])


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('二手车价格预测平台')
        self.setGeometry(400, 200, 250, 200)
        self.setFixedSize(1000, 650)
        self.setStyleSheet(
            "QWidget {  border: 1px solid #888888; border-radius: 10px; }")
        # 加载图片
        pixmap = QPixmap('image/main_window.png')
        # 缩小图片到指定尺寸，同时保持宽高比
        scaled_pixmap = pixmap.scaled(600, 600, Qt.KeepAspectRatio, Qt.SmoothTransformation)  # 缩小到100x100
        # 创建QLabel来显示缩小后的图片
        label = QLabel(self)
        label.setPixmap(scaled_pixmap)
        label.resize(600, 600)  # 设置QLabel的大小，以适应缩小后的图片
        label.move(350, 25)  # 设置QLabel的位置
        self.show()
        layout = QVBoxLayout()
        self.register_button = QPushButton('注册账号')
        self.register_button.setFixedSize(300, 50)
        self.register_button.clicked.connect(self.open_register)
        layout.addWidget(self.register_button)
        self.register_button.move(500, 20)
        self.login_button = QPushButton('登录账号')
        self.login_button.setFixedSize(300, 50)
        self.login_button.clicked.connect(self.open_login)
        layout.addWidget(self.login_button)
        self.setLayout(layout)

    def open_register(self):
        self.register_window = RegisterWindow()
        self.register_window.show()

    def open_login(self):
        self.login_window = LoginWindow()
        self.login_window.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())
